	Thank for you trying  Advanced CSV Converter

Advanced CSV Converter is a versatile yet easy-to-use conversion program.
It has a familiar Wizard-like interface but can also be used as a command-line
utility for batch file processing. Advanced CSV Converter supports all the 
modern data interchange formats, such as DBF, Excel(XLS,XLSX), XML, SQL, CSV, TXT, HTML,
RTF, PRG and others.

  Registration

  You can register the software right away using a secure online server.
  Your credit card information will be sent directly to the credit card
  processor via a secure channel (SSL) so that no one can intercept your
  personal data. You will be delivered a registration code immediately.

  Please visit to http://www.dbf2002.com/csv-converter/order.html  	

Copyright (C) HiBase Group, 2002-2012