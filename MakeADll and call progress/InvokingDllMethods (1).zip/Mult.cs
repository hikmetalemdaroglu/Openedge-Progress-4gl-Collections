// Multiply two numbers
using System; 
namespace MyMethods 
{
   public class MultiplyClass 
   {
      public static long Multiply(long x, long y) 
      {
         return (x*y); 
      }
   }
}
