File: readme.txt 
Updated: 31st May 2006 by Anthony Swindells

This sample code will work without Progress Dynamics but also contains code that works only with
Progress Dynamics and depends on the framework. For example, any Appserver support depends on the
Dynamics Appserver connection so for non Dynamics applications this would need to be modified to
connect to an Appserver as appropriate (if not running client/server).

Basically the code works without Dynamics but has many enhanced capabilities that leverages Dynamics.

To use the demo code, do the following:

1. Unzip contents of auditdemo.zip into your working directory. Be sure to keep folder names
2. You need to add additional PROPATH entries
	dynui\src
	dynui\src\adm2
	dynui\src\dynamics
3. Audit enable your ICFDB and any application databases
4. Load shipped audit policies
5. Load sample Dynamics audit policies (auditing\dynpolicy.xml) and events (auditing\_aud-event.ad)
6. Load sample ADO�s using dataset import
7. Regenerate your icfconfig.xml to include the new Audit Manager in all Dynamics sessions 

If not using Dynamics - use the auditing/auditquery.w test window
If using Dynamics - use the dynamics window dynauditquery (available from admin menu and audit button)

Some notes about the code:
--------------------------

You need to have at least 1 audit enabled database connected. You also need to set up appropriate 
audit permissions and ensure the current user has privilege to read the audit data. 
Also remember that nothing gets audited until you load the shipped policies /
set up your own audit policies for what you need to audit - using the Audit Policy Maintenance tool or
the API

It is recommended that the client session use the -s 32000 startup parameter if you have a lot of data.

You will have to create an alias called audit-db pointing at one of the audit enabled databases 
in order for the query code to compile, e.g. CREATE ALIAS AUDIT-DB FOR DATABASE Sports2000. For Dynamics,
this has been added to the src/dynamics/icfstart.p for the ICFDB database.

If you wish to open up the query window auditquery.w in the Appbuilder, you will need to connect to 
a temp-db database that has the dataset include files registered in it (via the temp-db maintenance tool 
in the Appbuilder). For convenience the zip file contains a temp-db.df file that can be used to load the 
schema of a temp-db database that will work. If you already have a temp-db database with schema in it, 
then simply register the prodataset include files using the utility yourself - before trying to open up 
the query window. The temp-db.df will have been extracted to your working directory in the /auditing 
subdirectory if you followed the steps above.

The sample code was created originally using the OERA templates from PSDN. It uses a data access object 
auditing/da_aud-audit-data2.p to query the audit data. There is currently 1 API implemented to return a 
dataset of audit data according to the passed in filter criteria.

There is a very simple example procedure with hard coded filters, sampleauditreport.p that shows some 
interaction with the data access object. The basic principal is to create a temp-table of filter 
criteria and get back a dataset.

The audit query window auditquery.w shows a GUI window that allows you to run the data access object and 
view the resultant data - according to the criteria specified. This demonstrates how to leverage the data 
access object with a UI.

Code is sample only and is incomplete
	shortcuts taken for simplicity (but commented)
Does not cater fully for internationalization, e.g. assumes American format in some places
Sample serviceadapter.p is massively simplified and only caters for AuditData Business Entity
There is no support for batching implemented
Code assumes Dynamics 10.1A01
Customizations are made in actual Dynamics and ADM2 source rather than in custom supers for simplicity � issues for future upgrades
Code makes use of 10.1A01 core functionality, e.g. OOABL

This code as written will work in a Dynamics Webclient session with an Appserver connected. If Dynamics did
not connect the Appserver, then the Appserver functionality will not work as it relies on the shared handle
gshAstraAppserver. For other Appserver environments appropriate code should be added to connect to the
Appserver manually.

