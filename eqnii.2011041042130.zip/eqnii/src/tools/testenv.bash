#!/bin/bash
# Test Environment

export PROPATH=/home/sauge/Desktop/Parallels/Home/Documents/Code/Progress/eqnii/src/tools
export DLC=/prg/101a

$DLC/bin/pro 
